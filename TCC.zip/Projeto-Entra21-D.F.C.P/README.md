## Projeto final do programa Entra21 2020 - D.F.C.P (Digital Finance Control Painel) - Equipe Overcash

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

Membros:

Cauê Victor Gomes
Kaiman de Mello Cunha
João Lucas Boldt Nunes
Stefany dos Santos Kulkamp

Tecnologias ultilizadas:

=> Visual Studio 2019
=> Visual Studio Code
=> Asp.Net Core MVC
=> HTML
=> C#
=> Css
=> JavaScript
=> Git
=> MySql



Produzido com:

ASP.NET Core - CoreUI Free Bootstrap Admin Template 

[CoreUI Free Bootstrap Admin Template](https://github.com/coreui/coreui-free-bootstrap-admin-template)

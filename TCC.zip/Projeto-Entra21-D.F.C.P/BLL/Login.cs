﻿using System;
using BLL.Interfaces;

namespace BLL
{
    public class Login : ILoginCadastro
    {
		
	}
}

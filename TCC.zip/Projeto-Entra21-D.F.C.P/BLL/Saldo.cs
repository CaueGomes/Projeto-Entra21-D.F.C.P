﻿using System;
using System.Collections.Generic;
using System.Text;
using BLL.Interfaces;


namespace BLL
{
    class Saldo : IPaginas
    {
    }
}
